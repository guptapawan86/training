### Confirm before live practice

The offline lab does not configure AEM or prove environment readiness. Ask the facilitator to confirm these gates with a participant-role account. Record unmet gates as **not ready**, with an owner.

| Gate | Confirm with the facilitator |
| --- | --- |
| Safe scope | Explicit environment-owner approval, an agreed delivery destination and participant-owned folders; a training path is not a security or publication boundary |
| Assets | Authorised JPG practice images, completed processing and verified metadata fields and review values |
| Search and CSV | Working scoped search and a rehearsed export/import using the actual schema, preserved paths and headers, and result checks |
| Fragments and gallery | Enabled Promo banner model, associated folder configuration, participant save/reopen permissions and tested multi-value image references |
| Delivery and Commerce | Known-working image URL and consumer, approved test product and confirmed manual URL, selector or integration route |
| Ownership | Named AEM/support and Commerce contacts; authors collect evidence rather than change technical mappings |
| Scheduling | Disposable image/fragment pair, approved destination, agreed time zone, status/cancellation checks and cleanup owner |

If a gate is unmet, agree a demonstration or evidence-only activity rather than claiming a live task succeeded. Model configuration, search indexes and a missing preview application belong to technical staff.

### Field mapping, confirm locally

These are proposed training properties beneath `jcr:content/metadata`, not verified customer configuration. Use the facilitator-confirmed mapping; do not change schemas or substitute an approval field.

| Label | Example property |
| --- | --- |
| Title | `dc:title` |
| Keywords | `dc:subject` |
| Alt text | `trainingAltText` |
| SKU | `trainingSku` |
| Usage | `trainingUsage` |
| Campaign | `trainingCampaign` |
| Review state | `trainingApproval` |

Preserve exact SKU text and verified multi-value conventions. Training review state does not establish Commerce eligibility or publication. The official integration uses its configured Commerce metadata contract, not the practice SKU field.

### Publication quick check

1. Confirm ownership and approval for the actual publication destination.
2. Check review approval separately from publication.
3. Check required models, fragments, image references, queries and configuration on the delivery tier.
4. Verify the consumer's actual delivery URL and access requirements.
5. Confirm the exact Commerce association and image roles through the configured route.
6. Confirm date filtering, time zones, image metadata and gallery order in the consuming app.
7. Escalate persistent delivery or cache issues with paths, exact SKU, publication time, URL, expected/actual results and a screenshot.

For immediate manual publication, deliver the image before its fragment. For scheduling, explicitly include both. Agree cleanup with the facilitator; do not delete shared or production content.

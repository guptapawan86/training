# 7-Eleven AEM Enablement Lab

Unzip the complete folder, then open `index.html` in a current browser. Keep all files and the `assets` folder together. No installation, build, server, login, or internet connection is needed to open the training.

Progress, quiz answers and notes are saved only in your browser. They are not shared with anyone or synchronized between devices. Clearing browser data, private browsing, or moving the folder may remove access to saved progress. Use the same browser and folder location each time.

Completing the exercises in the actual solution requires access to the separate training environment.

Use the arrows beside **Course** and **On this page** to collapse or reopen either rail independently. On smaller screens, these expandable panels appear above the lesson. The page outline links to visible sections and follows your position as you scroll; these navigation controls do not change your progress. When the package includes an account training list, use the cross at the top right of the black title bar, labelled **Return to training list**, to return to that list.

Use **Next course** to advance to the next topic after completing its exercises.
On checklist-only topics, the subtle **Mark all as complete** action sits beside forward navigation and completes only that topic's checklists. Knowledge checks must still be answered and checked.

Use the top-right copy icon on an authored prompt or file preview to copy its complete text. File previews show **Filename: {filename}**; the label is not copied. If clipboard access is unavailable, the text is selected for manual copying and a message explains the failure. Knowledge checks remain editable after a correct answer and after reload. Changing your selection saves a draft and clears that question's result; use **Check answer** again to grade it. Until the revised answer is checked and correct, progress decreases and later topics may be temporarily locked. Other saved answers, notes and later work are retained. Optional authored explanations for other answers appear after success.

Some knowledge checks group several questions under one **Check answers** button. Select an answer for every question before checking. Changing any answer clears the whole group's previous results and requires checking all its questions together again.

After completing every exercise, use **Finished!** on the final topic. The completion screen records no assessment score, certification or LMS submission: progress is saved only in this browser. Use the topics rail to revisit topics, answer explanations and Resources. If browser storage is unavailable, the training reports that progress could not be saved.
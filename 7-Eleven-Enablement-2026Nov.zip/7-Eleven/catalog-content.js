globalThis.createTrainingContent = data => {
  'use strict';
  const { profile, capabilities, assets, resources = { documentation: [], bestPractices: [], cheatSheets: [] } } = data;

  function gradeQuizQuestion(quiz, optionId) {
    const option = quiz.options.find(item => item.id === optionId);
    if (!option) throw new Error('Select one of the available answers.');
    const correct = option.correct === true;
    return { correct, message: correct ? 'Correct! Well done.' : 'Incorrect. Try again.', explanation: option.explanation };
  }

  function isStepComplete(saved, capabilityId, stepId) {
    const direct = saved?.find(entry => entry.id === stepId);
    if (direct) return direct.completed === true;
    const legacyId = capabilities.find(chapter => chapter.id === capabilityId)?.subExercises.find(step => step.id === stepId)?.legacyCompletionId;
    return Boolean(legacyId && saved?.some(entry => entry.id === legacyId && entry.completed === true));
  }

  function emptyCapabilities() {
    return capabilities.map(({ id, subExercises }) => ({ id, subExercises: subExercises.map(({ id: subId }) => ({ id: subId, completed: false })) }));
  }

  function summarize(rows) {
    const capabilityProgress = capabilities.map(({ id, subExercises }) => {
      const saved = rows?.find(row => row.id === id)?.subExercises || [];
      const completed = subExercises.filter(item => isStepComplete(saved, id, item.id)).length;
      return { id, completed, total: subExercises.length, percent: subExercises.length ? Math.round(completed * 100 / subExercises.length) : 100 };
    });
    const completed = capabilityProgress.reduce((sum, row) => sum + row.completed, 0);
    const total = capabilityProgress.reduce((sum, row) => sum + row.total, 0);
    return { capabilityProgress, overallPercent: total ? Math.round(completed * 100 / total) : 100 };
  }

  function formatText(text, escapeValue = value => value) {
    const values = { '{{customerName}}': profile.customerName, '{{solutionName}}': profile.solutionName };
    return Object.entries(values).reduce((result, [placeholder, value]) => result.replaceAll(placeholder, () => escapeValue(value)), text);
  }

  return Object.freeze({ profile, capabilities, resources, assets, gradeQuizQuestion, isStepComplete, emptyCapabilities, summarize, formatText });
};

if (globalThis.TrainingData) globalThis.TrainingContent = globalThis.createTrainingContent(globalThis.TrainingData);
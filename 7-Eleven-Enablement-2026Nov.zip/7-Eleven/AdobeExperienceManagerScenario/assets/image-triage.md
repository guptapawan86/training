### Triage checklist

1. Establish the exact product, image, environment and symptom. For mobile-app promo banners, verify actual JPG format and the right product/category; changing an extension is not conversion.
2. Inspect review and publication history independently.
3. Compare the exact product identifier and actual association mapping.
4. Test the consumer's real delivery URL and access requirements, not only an author preview.
5. Inspect Commerce linkage, synchronisation and required image roles.
6. Compare with a known-working product before investigating caching or propagation delays.

A 404 alone is not a diagnosis. Compare list view with product details, and respect intentionally authenticated delivery.

### Evidence handoff

Record asset/fragment paths, exact SKU, publication time, delivery URL, expected versus actual result and a screenshot. Confirm the support contact and next action with the facilitator. Authors do not change query, role mapping or cache settings; never put credentials in notes.

### Live-walkthrough safeguards

The offline scenario makes no live changes. Before any live rehearsal, the facilitator must confirm an approved environment, actual publication destination, owned practice resources, permissions and technical readiness. A training folder is not an access or publication boundary.

Approval is not publication. Fragment dates require application logic or an explicit schedule. For immediate manual publishing, deliver the JPG image first and then the fragment; for a schedule, explicitly include both and confirm time zone, status and delivery.

The facilitator owns cancellation, unpublishing and removal of authorised test resources. Record unresolved cleanup with an owner; do not change shared or production content.

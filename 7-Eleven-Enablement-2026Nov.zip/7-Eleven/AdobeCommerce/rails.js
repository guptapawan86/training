globalThis.createTrainingRails = () => {
  'use strict';
  const byId = id => document.getElementById(id);
  const content = byId('chapter-content');
  const layout = byId('training-layout');
  const leftContent = byId('left-rail-content');
  const leftToggle = byId('left-rail-toggle');
  const outlineContent = byId('outline-content');
  const outlineToggle = byId('outline-toggle');
  const list = byId('page-outline');
  const masthead = document.querySelector('.masthead');
  const wide = window.matchMedia('(min-width:1100px)');
  let desktopLeftOpen = true;
  let desktopOutlineOpen = true;
  let mobileLeftOpen = false;
  let mobileOutlineOpen = false;
  let headerHeight = 0;
  let entries = [];
  let active = null;
  let clicked = null;
  let scheduled = false;

  function showPanel(panel, toggle, open) {
    if (!open && panel.contains(document.activeElement)) toggle.focus({ preventScroll: true });
    panel.hidden = !open;
    toggle.setAttribute('aria-expanded', String(open));
  }

  function applyRails() {
    const leftOpen = wide.matches ? desktopLeftOpen : mobileLeftOpen;
    showPanel(leftContent, leftToggle, leftOpen);
    leftToggle.setAttribute('aria-label', `${leftOpen ? 'Collapse' : 'Expand'} topics rail`);
    layout.classList.toggle('left-rail-collapsed', !leftOpen);
    const outlineOpen = wide.matches ? desktopOutlineOpen : mobileOutlineOpen;
    showPanel(outlineContent, outlineToggle, outlineOpen);
    layout.classList.toggle('right-rail-collapsed', !outlineOpen);
    outlineToggle.setAttribute('aria-label', `${outlineOpen ? 'Collapse' : 'Expand'} page sections rail`);
    clicked = null;
    schedule();
  }

  function syncHeader() {
    const height = Math.ceil(masthead.getBoundingClientRect().height);
    if (height === headerHeight) return;
    headerHeight = height;
    document.documentElement.style.setProperty('--masthead-height', `${height}px`);
  }

  function updateActive() {
    if (!entries.length) return;
    const offset = headerHeight + 24;
    const bottom = document.scrollingElement.scrollHeight - window.innerHeight;
    let current = entries[0];
    for (const entry of entries) {
      if (entry.heading.getBoundingClientRect().top > offset + 1) break;
      current = entry;
    }
    if (bottom > 1 && window.scrollY >= bottom - 2) current = entries.at(-1);
    // A clicked heading may be too near the page end to reach the masthead.
    if (clicked && Math.abs(window.scrollY - clicked.y) <= 1) current = clicked.entry;
    else clicked = null;
    const reveal = !outlineContent.hidden && list.scrollHeight > list.clientHeight;
    const linkBox = reveal ? current.link.getBoundingClientRect() : null;
    const listBox = reveal ? list.getBoundingClientRect() : null;
    if (active !== current.link) {
      active?.removeAttribute('aria-current');
      current.link.setAttribute('aria-current', 'location');
      active = current.link;
    }
    if (reveal) {
      if (linkBox.top < listBox.top) list.scrollTop += linkBox.top - listBox.top;
      else if (linkBox.bottom > listBox.bottom) list.scrollTop += linkBox.bottom - listBox.bottom;
    }
  }

  function schedule() {
    if (scheduled) return;
    scheduled = true;
    window.requestAnimationFrame(() => { scheduled = false; updateActive(); });
  }

  function refresh() {
    const page = content.querySelector('article');
    const reserved = new Set([...document.querySelectorAll('[id]')].map(node => node.id));
    const headings = [...content.querySelectorAll('h1,h2,h3,h4,h5,h6,details>summary')].filter(heading =>
      !heading.closest('.chapter-header,.quiz-question') && heading.textContent.trim());
    const visible = [];
    for (const heading of headings) {
      const title = heading.getAttribute('data-outline-title') ?? heading.textContent.trim();
      if (!heading.id) {
        const slug = title.normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-|-$/g, '') || 'section';
        const panel = heading.closest('[role="tabpanel"]');
        const base = `section-${page.id || 'resources'}-${panel ? `${panel.id}-` : ''}${slug}`;
        let id = base;
        for (let suffix = 2; reserved.has(id); suffix++) id = `${base}-${suffix}`;
        heading.id = id;
        reserved.add(id);
      }
      if (!heading.matches('summary') && !heading.hasAttribute('tabindex')) heading.tabIndex = -1;
      let disclosed = true;
      for (let ancestor = heading.parentElement; ancestor && ancestor !== content; ancestor = ancestor.parentElement) {
        if (ancestor.matches('details:not([open])') && !ancestor.querySelector(':scope > summary')?.contains(heading)) {
          disclosed = false;
          break;
        }
      }
      if (!disclosed || !heading.getClientRects().length) continue;
      const card = heading.closest('.resource-card');
      const level = card ? heading === card.querySelector('h3') ? 2 : Number(heading.tagName.slice(1)) + 2
        : heading.matches('summary') ? heading.closest('.guided-steps') ? 5 : 3 : Number(heading.tagName.slice(1));
      visible.push({ heading, title, level });
    }
    const baseLevel = Math.min(...visible.map(entry => entry.level));
    entries = visible.map(({ heading, title, level }) => {
      const item = document.createElement('li');
      item.dataset.level = String(Math.min(3, Math.max(0, level - baseLevel)));
      const link = document.createElement('a');
      link.href = `#${encodeURIComponent(heading.id)}`;
      link.dataset.section = heading.id;
      link.textContent = title;
      item.append(link);
      return { heading, link, item };
    });
    list.replaceChildren(...entries.map(entry => entry.item));
    byId('outline-empty').hidden = entries.length > 0;
    active = null;
    clicked = null;
    schedule();
  }

  leftToggle.addEventListener('click', () => {
    if (wide.matches) desktopLeftOpen = !desktopLeftOpen;
    else mobileLeftOpen = !mobileLeftOpen;
    applyRails();
  });
  outlineToggle.addEventListener('click', () => {
    if (wide.matches) desktopOutlineOpen = !desktopOutlineOpen;
    else mobileOutlineOpen = !mobileOutlineOpen;
    applyRails();
  });
  list.addEventListener('click', event => {
    const link = event.target.closest('a[data-section]');
    const entry = entries.find(item => item.link === link);
    if (!entry) return;
    event.preventDefault();
    entry.heading.focus({ preventScroll: true });
    entry.heading.scrollIntoView({ block: 'start', behavior: 'auto' });
    clicked = { entry, y: window.scrollY };
    schedule();
  });
  content.addEventListener('toggle', refresh, true);
  window.addEventListener('scroll', schedule, { passive: true });
  window.addEventListener('resize', () => { syncHeader(); schedule(); });
  wide.addEventListener('change', applyRails);
  const observer = new window.ResizeObserver(() => { syncHeader(); schedule(); });
  observer.observe(masthead);
  observer.observe(content);
  syncHeader();
  applyRails();
  return Object.freeze({ refresh });
};

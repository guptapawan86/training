### Naming convention

- **SKU prefix:** ask the facilitator for a unique sandbox prefix and assigned practice product SKU.
- **Category name:** use the facilitator's unique practice category name, for example **Weekly Deal Practice A**.

Do not reuse another participant's values or import the unchanged example SKU.

### Glossary

- **SKU:** A product's unique text identifier, usually readable.
- **Product ID:** A product's unique numeric system identifier, separate from its SKU.
- **Category ID:** A category's unique numeric system identifier.
- **Cart Price Rule:** A discount rule applied automatically in the cart based on defined conditions.
- **Position / ranking:** The manual order in which products appear within a category.
- **Products Only:** A display mode showing the assigned product grid without additional static content.
- **Add/Update:** A CSV import mode that creates or updates products, matched by SKU.

### CSV example

Export a sample Products CSV from Commerce to use as your actual template. The row below is a working example in that format.

```asset
assets/7eleven-sample-product.csv
```

Replace the entire example SKU with a unique value using the facilitator-assigned sandbox prefix before importing. This export uses `product_online` (1 = enabled, 0 = disabled) rather than a status column. Categories use full paths separated by commas.

[Download sample product CSV](assets/7eleven-sample-product.csv)

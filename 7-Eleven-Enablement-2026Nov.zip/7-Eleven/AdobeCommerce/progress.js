globalThis.createTrainingProgress = content => {
  'use strict';
  const { capabilities, emptyCapabilities, gradeQuizQuestion, isStepComplete, profile } = content;
  const storageKey = `${profile.accountName}.${profile.solution}.${profile.trainingEdition}`;

  function completedSteps(state, chapterIndex) {
    const chapter = capabilities[chapterIndex];
    if (!chapter) return [];
    const saved = state.capabilities.find(row => row.id === chapter.id)?.subExercises || [];
    return chapter.subExercises.map(step => isStepComplete(saved, chapter.id, step.id));
  }

  function availableChapter(state) {
    const firstIncomplete = capabilities.findIndex((chapter, index) => !completedSteps(state, index).every(Boolean));
    return firstIncomplete < 0 ? capabilities.length - 1 : firstIncomplete;
  }

  function canOpenChapter(state, index) {
    return Number.isInteger(index) && index >= 0 && index < capabilities.length && index <= state.unlockedIndex && index <= availableChapter(state);
  }

  function canAdvance(state) {
    return state.chapterIndex < capabilities.length - 1 && completedSteps(state, state.chapterIndex).every(Boolean);
  }

  function createState(raw = {}) {
    if (!raw || typeof raw !== 'object' || raw.version !== 1) raw = {};
    const state = {
      version: 1,
      capabilities: emptyCapabilities(),
      answers: {},
      notes: {},
      chapterIndex: 0,
      unlockedIndex: 0,
    };
    capabilities.forEach((chapter, chapterIndex) => {
      const saved = Array.isArray(raw.capabilities) ? raw.capabilities.find(row => row?.id === chapter.id)?.subExercises : [];
      chapter.subExercises.forEach((step, stepIndex) => {
        if (step.quiz) {
          const savedAnswer = raw.answers?.[step.id];
          const answer = typeof savedAnswer === 'string' ? savedAnswer : savedAnswer?.optionId;
          if (step.quiz.options.some(option => option.id === answer)) {
            const submitted = savedAnswer?.submitted !== false;
            state.answers[step.id] = { questionRef: `capabilities[${chapterIndex}].subExercises[${stepIndex}]`, optionId: answer, ...(!submitted ? { submitted: false } : {}) };
            state.capabilities[chapterIndex].subExercises[stepIndex].completed = submitted && gradeQuizQuestion(step.quiz, answer).correct;
          }
        } else {
          state.capabilities[chapterIndex].subExercises[stepIndex].completed = Array.isArray(saved) && isStepComplete(saved, chapter.id, step.id);
        }
      });
      for (const group of new Set(chapter.subExercises.map(step => step.knowledgeCheck).filter(Boolean))) {
        const questions = chapter.subExercises.filter(step => step.knowledgeCheck === group);
        if (questions.every(step => state.answers[step.id] && state.answers[step.id].submitted !== false)) continue;
        for (const step of questions) {
          if (state.answers[step.id]) state.answers[step.id].submitted = false;
          state.capabilities[chapterIndex].subExercises.find(saved => saved.id === step.id).completed = false;
        }
      }
      state.notes[chapter.id] = chapter.notes && typeof raw.notes?.[chapter.id] === 'string' ? raw.notes[chapter.id].slice(0, 10000) : '';
    });
    const available = availableChapter(state);
    state.unlockedIndex = Number.isInteger(raw.unlockedIndex) ? Math.min(Math.max(0, raw.unlockedIndex), available) : 0;
    state.chapterIndex = canOpenChapter(state, raw.chapterIndex) ? raw.chapterIndex : Math.min(state.unlockedIndex, available);
    return state;
  }

  function updateStep(state, chapterId, stepId, completed, answer) {
    const chapterIndex = capabilities.findIndex(chapter => chapter.id === chapterId);
    const stepIndex = capabilities[chapterIndex]?.subExercises.findIndex(step => step.id === stepId);
    if (chapterIndex < 0 || stepIndex < 0 || stepIndex === undefined || typeof completed !== 'boolean') throw new Error('Invalid exercise.');
    const step = capabilities[chapterIndex].subExercises[stepIndex];
    const next = createState(state);
    if (step.quiz) {
      if (step.knowledgeCheck && completed) throw new Error('Check all answers in this knowledge check together.');
      const result = gradeQuizQuestion(step.quiz, answer);
      if (step.knowledgeCheck) {
        for (const question of capabilities[chapterIndex].subExercises.filter(item => item.knowledgeCheck === step.knowledgeCheck)) {
          if (next.answers[question.id]) next.answers[question.id].submitted = false;
        }
      }
      next.answers[step.id] = { questionRef: `capabilities[${chapterIndex}].subExercises[${stepIndex}]`, optionId: answer, ...(!completed ? { submitted: false } : {}) };
      next.capabilities[chapterIndex].subExercises[stepIndex].completed = completed && result.correct;
    } else {
      next.capabilities[chapterIndex].subExercises[stepIndex].completed = completed;
    }
    return createState(next);
  }

  function checkQuizGroup(state, chapterId, groupId, answers) {
    const chapter = capabilities.find(item => item.id === chapterId);
    const questions = chapter?.subExercises.filter(step => step.knowledgeCheck === groupId) ?? [];
    if (questions.length < 2 || !answers || typeof answers !== 'object' || Array.isArray(answers)) throw new Error('Invalid knowledge check.');
    for (const step of questions) gradeQuizQuestion(step.quiz, answers[step.id]);
    const next = createState(state);
    for (const step of questions) {
      const stepIndex = chapter.subExercises.indexOf(step);
      next.answers[step.id] = { questionRef: `capabilities[${capabilities.indexOf(chapter)}].subExercises[${stepIndex}]`, optionId: answers[step.id] };
    }
    return createState(next);
  }

  function completeChapter(state) {
    const chapter = capabilities[state.chapterIndex];
    if (chapter.subExercises.some(step => step.quiz)) throw new Error('Answer each quiz question to complete this chapter.');
    const next = createState(state);
    next.capabilities[state.chapterIndex].subExercises.forEach(step => { step.completed = true; });
    return next;
  }

  function advance(state) {
    if (!canAdvance(state)) throw new Error('Complete every exercise in this chapter to continue.');
    const next = createState(state);
    next.chapterIndex += 1;
    next.unlockedIndex = Math.max(next.unlockedIndex, next.chapterIndex);
    return next;
  }

  function load(storage) {
    try {
      const text = storage.getItem(storageKey);
      if (text === null) return { state: createState(), error: '' };
      const raw = JSON.parse(text);
      if (!raw || raw.version !== 1) throw new Error('Unsupported progress data.');
      return { state: createState(raw), error: '' };
    } catch {
      return { state: createState(), error: 'Saved progress could not be loaded. Browser storage may be unavailable or damaged.' };
    }
  }

  function save(storage, state) {
    try {
      storage.setItem(storageKey, JSON.stringify(createState(state)));
      return '';
    } catch {
      return 'Progress could not be saved in this browser. Check storage permissions or available space.';
    }
  }

  function reset() {
    return createState();
  }

  return Object.freeze({ storageKey, createState, completedSteps, availableChapter, canOpenChapter, canAdvance, updateStep, checkQuizGroup, completeChapter, advance, load, save, reset });
};

if (globalThis.TrainingContent) globalThis.TrainingProgress = globalThis.createTrainingProgress(globalThis.TrainingContent);
(() => {
  'use strict';
  const { capabilities, profile, summarize, gradeQuizQuestion, formatText, assets } = globalThis.TrainingContent;
  const resources = globalThis.TrainingContent.resources ?? { documentation: [], bestPractices: [], cheatSheets: [] };
  const resourceSections = { documentation: 'Documentation', bestPractices: 'Best practices', cheatSheets: 'Cheat sheet' };
  const resourceIndex = new Map(Object.entries(resources).flatMap(([section, items]) => items.map(item => [item.id, { ...item, section }])));
  const progress = globalThis.TrainingProgress;
  const byId = id => document.getElementById(id);
  const rails = globalThis.createTrainingRails();
  const escape = value => String(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
  let storage;
  try { storage = window.localStorage; } catch { storage = null; }
  const initial = progress.load(storage);
  let state = initial.state;
  let savedNotes = { ...state.notes };
  let storageError = initial.error;
  let resourceSection = null;
  let resourceError = '';
  let printingSheet = null;
  let showCompletion = false;
  const collapsedPractices = new Set();
  const quizErrors = new Set();
  const assetUrls = Object.fromEntries(Object.values(assets).map(asset => [asset.path, URL.createObjectURL(new Blob([Uint8Array.from(atob(asset.base64), character => character.charCodeAt(0))], { type: `${asset.mime};charset=utf-8` }))]));
  const contentHtml = value => formatText(value, escape);

  function showStorageStatus(saved = false) {
    byId('storage-error').hidden = !storageError;
    byId('storage-error').textContent = storageError;
    byId('save-status').textContent = storageError ? 'Not saved' : saved ? 'Saved' : 'Ready';
  }

  function commit(next, redraw = true) {
    state = progress.createState(next);
    storageError = progress.save(storage, state);
    if (!storageError) savedNotes = { ...state.notes };
    if (redraw) render();
    else renderNavigation();
    showStorageStatus(true);
  }

  function renderQuizQuestion(step, completed, questionNumber, action = '', grouped = false) {
    const savedAnswer = state.answers[step.id];
    const answer = savedAnswer?.optionId;
    const pending = savedAnswer?.submitted === false;
    const feedback = answer && !pending ? gradeQuizQuestion(step.quiz, answer) : null;
    const otherAnswers = completed && feedback?.correct
      ? step.quiz.options.filter(option => option.correct !== true && typeof option.explanation === 'string' && option.explanation.trim()) : [];
    return `<fieldset><legend>${questionNumber}. ${escape(formatText(step.quiz.prompt))}</legend><div class="quiz-options">${step.quiz.options.map((option, index) => `<label class="quiz-option${completed && option.id === answer ? ' correct-option' : ''}"><input type="radio" id="quiz-${step.id}-${index}" data-quiz-option="${step.id}" name="${step.id}" value="${option.id}"${answer === option.id ? ' checked' : ''} required><span>${escape(formatText(option.label))}</span></label>`).join('')}</div></fieldset>
      ${action}
      ${!grouped && quizErrors.has(step.id) ? '<p class="quiz-feedback" role="alert">Select an answer before checking.</p>' : ''}
      ${!grouped && pending ? '<p class="quiz-pending" role="status" aria-live="polite">Answer changed. Check answer to update your result.</p>' : ''}
      ${feedback ? `<div class="quiz-feedback${feedback.correct ? ' correct' : ''}" role="status" aria-live="polite"><strong>${grouped ? escape(feedback.message) : feedback.correct ? '1/1 correct (100%). Knowledge check passed.' : '0/1 correct (0%). Incorrect. Try again.'}</strong><p>${escape(formatText(feedback.explanation))}</p></div>` : ''}
      ${otherAnswers.length ? `<details class="quiz-review"><summary>Review other answers</summary><ul>${otherAnswers.map(option => `<li><strong>${escape(option.id)}) ${escape(formatText(option.label))}</strong><p>${escape(formatText(option.explanation))}</p></li>`).join('')}</ul></details>` : ''}`;
  }

  function renderQuiz(step, completed, questionNumber) {
    return `<form class="quiz-question" data-quiz="${step.id}">${renderQuizQuestion(step, completed, questionNumber, `<button type="submit" id="check-answer-${step.id}" class="primary quiz-submit">Check answer</button>`)}</form>`;
  }

  function renderQuizGroup(chapter, groupId, steps) {
    const questions = chapter.subExercises.filter(step => step.knowledgeCheck === groupId);
    const answered = questions.filter(step => state.answers[step.id]).length;
    const checked = answered === questions.length && questions.every(step => state.answers[step.id].submitted !== false);
    const correct = questions.filter(step => steps[chapter.subExercises.indexOf(step)]).length;
    const guidanceId = `knowledge-check-${chapter.id}-${groupId}-guidance`;
    return `<form class="quiz-question quiz-group" data-quiz-group="${groupId}" aria-labelledby="knowledge-check-${chapter.id}-${groupId}-title" aria-describedby="${guidanceId}">
      <p id="${guidanceId}" class="sr-only">Answer every question before checking this knowledge check.</p>
      ${questions.map((step, index) => `<div class="quiz-group-question">${contentHtml(step.html)}${practiceCallouts(step.bestPractices, step.id)}${renderQuizQuestion(step, steps[chapter.subExercises.indexOf(step)], index + 1, '', true)}</div>`).join('')}
      <button type="submit" id="check-group-${groupId}" class="primary quiz-submit"${answered < questions.length ? ' disabled' : ''}>Check answers</button>
      ${quizErrors.has(`group:${groupId}`) ? '<p class="quiz-feedback" role="alert">Answer every question before checking this knowledge check.</p>' : ''}
      ${answered && !checked ? '<p class="quiz-pending" role="status" aria-live="polite">Check answers to grade all questions together. Previous group results no longer apply.</p>' : ''}
      ${checked ? `<div class="quiz-feedback quiz-group-result${correct === questions.length ? ' correct' : ''}" role="status" aria-live="polite"><strong>${correct}/${questions.length} correct (${Math.round(correct * 100 / questions.length)}%). ${correct === questions.length ? 'Knowledge check passed.' : 'Review your answers and try again.'}</strong></div>` : ''}
    </form>`;
  }

  function resourceLink(item) {
    return `<a href="#resource-${escape(item.id)}" data-resource="${escape(item.id)}">${escape(item.title)}</a>`;
  }

  function practiceGuidance(item) {
    return `<dl class="practice-guidance">${[['recommendation', 'Recommendation'], ['rationale', 'Why'], ['pitfall', 'Common pitfall']].map(([key, label]) => `<div><dt>${label}</dt><dd>${escape(formatText(item[key]))}</dd></div>`).join('')}</dl>`;
  }

  function practiceCallouts(ids = [], scope = capabilities[state.chapterIndex].id) {
    return ids.map(id => {
      const item = resourceIndex.get(id);
      const key = `${scope}:${id}`;
      return `<details class="best-practice" data-practice="${escape(key)}"${collapsedPractices.has(key) ? '' : ' open'}><summary>Best practice: ${escape(item.title)}</summary>${practiceGuidance(item)}<p class="resource-context-link">In Resources: ${resourceLink(item)}</p></details>`;
    }).join('');
  }

  function courseComplete() {
    return capabilities.some(chapter => chapter.subExercises.length) && capabilities.every((chapter, index) => progress.completedSteps(state, index).every(Boolean));
  }

  function renderCompletion() {
    return `<article class="completion-page"><header class="chapter-header completion-hero"><svg class="completion-mark" viewBox="0 0 80 80" aria-hidden="true" focusable="false"><circle cx="40" cy="40" r="40"/><path d="m26 40 10 11 19-25"/></svg><h2>Training complete</h2><p class="completion-percent">100% <span>complete</span></p><p>${storageError ? 'Your exercises are complete, but progress could not be saved in this browser.' : 'Your training progress is saved in this browser. Revisit any topic or resource whenever you need it.'}</p><p class="completion-local">This is not a certification or an assessment score, it only reflects the completion of this training. Progress is not sent to a learning management system.</p></header></article>`;
  }

  function renderChapter() {
    const chapter = capabilities[state.chapterIndex];
    const steps = progress.completedSteps(state, state.chapterIndex);
    const allDone = steps.every(Boolean);
    const lastChapter = state.chapterIndex === capabilities.length - 1;
    return `<article id="${chapter.id}">
      <header class="chapter-header topic-hero"><p class="chapter-count">Topic ${String(state.chapterIndex + 1).padStart(2, '0')} / ${capabilities.length}</p><h2>${escape(chapter.title)}</h2>
      ${chapter.learn ? `<p class="chapter-learn">${escape(formatText(chapter.learn))}</p>` : ''}
      <ul class="topic-metadata" aria-label="Topic details"><li><span>Solution</span> ${escape(profile.solutionName)}</li><li>${chapter.subExercises.length ? `${chapter.subExercises.length} ${chapter.subExercises.length === 1 ? 'exercise' : 'exercises'}` : 'Reading topic'}</li></ul></header>
      ${chapter.access ? `<p class="chapter-access"><strong>How to access:</strong> ${escape(formatText(chapter.access))}</p>` : ''}
      ${contentHtml(chapter.html)}
      ${practiceCallouts(chapter.bestPractices)}
      ${chapter.subExercises.length ? '<h3>Exercises</h3>' : ''}
      <ol class="guided-steps" role="list">${chapter.subExercises.map((step, index) => {
        if (step.knowledgeCheck) return chapter.subExercises.find(item => item.knowledgeCheck === step.knowledgeCheck) === step
          ? `<li><h4 class="step-title" id="knowledge-check-${chapter.id}-${step.knowledgeCheck}-title">Knowledge check</h4>${renderQuizGroup(chapter, step.knowledgeCheck, steps)}</li>` : '';
        return `<li><h4 class="step-title">${escape(step.title)}</h4>${contentHtml(step.html)}${practiceCallouts(step.bestPractices, step.id)}${step.type === 'quiz' ? renderQuiz(step, steps[index], chapter.subExercises.slice(0, index + 1).filter(item => item.quiz).length) : `<label class="check"><input type="checkbox" data-step="${step.id}"${steps[index] ? ' checked' : ''}>Mark as complete</label>`}</li>`;
      }).join('')}</ol>
      ${chapter.furtherReading?.length ? `<section class="further-reading" aria-label="Further reading"><h3>Further reading</h3><ul>${chapter.furtherReading.map(id => `<li>${resourceLink(resourceIndex.get(id))}</li>`).join('')}</ul><p>Documentation links in Resources require internet access.</p></section>` : ''}
      ${chapter.notes ? `<details class="notes"><summary>My notes</summary><textarea id="chapter-notes" maxlength="10000" aria-label="Notes for ${escape(chapter.title)}">${escape(state.notes[chapter.id])}</textarea></details>` : ''}
      <div class="chapter-next"><div class="chapter-next-actions"><button type="button" id="previous-chapter"${state.chapterIndex === 0 ? ' disabled' : ''}><span aria-hidden="true">&larr;</span> Previous</button><div class="chapter-forward-actions">${chapter.subExercises.length && !chapter.subExercises.some(step => step.quiz) ? `<button type="button" id="complete-chapter"${allDone ? ' disabled' : ''}>Mark all as complete</button>` : ''}${!lastChapter ? `<button type="button" class="primary"${!allDone ? ' aria-describedby="chapter-next-guidance"' : ''} id="next-chapter"${progress.canAdvance(state) ? '' : ' disabled'}>Next course <span aria-hidden="true">&rarr;</span></button>` : courseComplete() ? '<button type="button" class="primary" id="finish-training">Finished! <span aria-hidden="true">&rarr;</span></button>' : ''}</div></div>${!allDone ? '<p id="chapter-next-guidance">Complete every exercise in this topic to continue.</p>' : ''}</div>
    </article>`;
  }

  function resourcePanel(section) {
    const items = resources[section];
    if (section === 'documentation') {
      return items.map(item => `<div class="resource-card documentation-card" id="resource-${escape(item.id)}" tabindex="-1"><h3 data-outline-title="${escape(item.title)}"><a href="${escape(item.url)}" target="_blank" rel="noopener noreferrer">${escape(item.title)}<svg class="external-link-icon" viewBox="0 0 14 14" aria-hidden="true" focusable="false"><path d="M4 3h7v7M11 3l-8 8"/></svg><span class="sr-only"> (opens a new tab; internet required)</span></a></h3><p>${escape(item.description)}</p></div>`).join('');
    }
    if (section === 'bestPractices') {
      return items.map(item => `<section class="resource-card" id="resource-${escape(item.id)}" tabindex="-1"><h3>${escape(item.title)}</h3>${practiceGuidance(item)}</section>`).join('');
    }
    return items.map(item => `<section class="resource-card cheat-sheet" id="resource-${escape(item.id)}" tabindex="-1"><h3>${escape(item.title)}</h3><div class="resource-actions"><button type="button" data-print-sheet="${escape(item.id)}">Print / Save as PDF</button><a class="download" href="${escape(item.download)}" data-asset="${escape(item.download)}" download="${escape(item.filename)}">Download Markdown</a></div>${contentHtml(item.html)}</section>`).join('');
  }

  function renderResources() {
    const sections = Object.entries(resourceSections).filter(([key]) => resources[key].length);
    const tabs = sections.length ? `<div class="resource-navigation" role="tablist" aria-label="Resources">${sections.map(([key, title]) => `<button type="button" role="tab" id="resource-tab-${key}" data-resource-section="${key}" aria-controls="resource-panel-${key}" aria-selected="${key === resourceSection}" tabindex="${key === resourceSection ? '0' : '-1'}">${title}</button>`).join('')}</div>` : '';
    return `<article class="resources"><header class="chapter-header topic-hero"><p class="chapter-count">Training materials</p><h2>Resources</h2></header><a href="#${capabilities[state.chapterIndex].id}" id="back-to-topic">Back to current topic</a>${tabs}${resourceError ? `<p class="error" role="alert">${resourceError}</p>` : ''}${sections.map(([key]) => `<section class="resource-section" role="tabpanel" id="resource-panel-${key}" aria-labelledby="resource-tab-${key}" tabindex="0"${key === resourceSection ? '' : ' hidden'}>${resourcePanel(key)}</section>`).join('')}${!sections.length && !resourceError ? '<p>No participant resources have been added to this training.</p>' : ''}</article>`;
  }

  function renderNavigation() {
    byId('chapter-navigation').innerHTML = capabilities.map((chapter, index) => {
      const steps = progress.completedSteps(state, index);
      const completed = steps.filter(Boolean).length;
      const hasNotes = Boolean(savedNotes[chapter.id]?.trim());
      return `<button type="button" class="nav-chapter${steps.every(Boolean) ? ' topic-complete' : ''}" data-chapter="${index}"${progress.canOpenChapter(state, index) ? '' : ' disabled'}${!showCompletion && resourceSection === null && index === state.chapterIndex ? ' aria-current="step"' : ''} aria-label="${escape(chapter.title)}, ${completed} of ${steps.length} complete${hasNotes ? ', Saved notes' : ''}"><span class="nav-number" aria-hidden="true">${String(index + 1).padStart(2, '0')}${steps.every(Boolean) ? '<svg viewBox="0 0 16 16" focusable="false"><path d="m3 8 3 3 7-7"/></svg>' : ''}</span><span class="nav-title">${escape(chapter.title)}${hasNotes ? '<svg class="saved-note" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><title>Saved notes</title><path d="M3 1.5h7l3 3v10H3zM10 1.5v3h3M5.5 8h5M5.5 11h4"/></svg>' : ''}</span></button>`;
    }).join('');
  }

  function render() {
    if (!courseComplete()) showCompletion = false;
    renderNavigation();
    byId('resources-button').setAttribute('aria-current', resourceSection !== null ? 'page' : 'false');
    const allSteps = capabilities.flatMap((chapter, index) => progress.completedSteps(state, index));
    const completedTopics = capabilities.filter((chapter, index) => progress.completedSteps(state, index).every(Boolean)).length;
    byId('overall-progress').innerHTML = `<label for="course-progress">${summarize(state.capabilities).overallPercent}% complete</label><progress id="course-progress" max="${allSteps.length || 1}" value="${allSteps.filter(Boolean).length}" aria-label="Overall exercise progress"></progress><span class="topic-total">${completedTopics} / ${capabilities.length} topics complete</span>`;
    byId('chapter-content').innerHTML = showCompletion ? renderCompletion() : resourceSection !== null ? renderResources() : renderChapter();
    byId('chapter-content').querySelectorAll('a[data-asset]').forEach(link => { link.href = assetUrls[link.dataset.asset]; });
    rails.refresh();
    showStorageStatus();
  }

  function focusChapter() {
    byId('chapter-content').focus({ preventScroll: true });
    byId('chapter-content').scrollIntoView({ block: 'start' });
  }

  function clearResourceHash() {
    if (window.location?.hash.startsWith('#resource-')) window.history.replaceState(null, '', window.location.href.split('#')[0]);
  }

  function openResource(id) {
    showCompletion = false;
    const item = resourceIndex.get(id);
    resourceSection = item?.section ?? '';
    resourceError = item ? '' : 'This resource is not available in this training. Choose a tab above or return to your current topic.';
    if (!item) resourceSection = Object.keys(resourceSections).find(key => resources[key].length) ?? '';
    render();
    if (!item) { focusChapter(); return; }
    const target = byId(`resource-${id}`);
    target.focus({ preventScroll: true });
    target.scrollIntoView({ block: 'start' });
  }

  function finishPrint() {
    printingSheet?.removeAttribute('data-printing');
    printingSheet = null;
  }

  byId('chapter-navigation').addEventListener('click', event => {
    const button = event.target.closest('[data-chapter]');
    if (!button) return;
    const index = Number(button.dataset.chapter);
    if (!progress.canOpenChapter(state, index)) return;
    showCompletion = false;
    resourceSection = null;
    clearResourceHash();
    commit({ ...state, chapterIndex: index });
    focusChapter();
  });
  byId('resources-button').addEventListener('click', () => {
    showCompletion = false;
    resourceError = '';
    resourceSection = Object.keys(resourceSections).find(key => resources[key].length) ?? '';
    clearResourceHash();
    render();
    focusChapter();
  });
  function openCompletion() {
    if (!courseComplete()) return;
    resourceSection = null;
    clearResourceHash();
    showCompletion = true;
    render();
    focusChapter();
  }
  function selectResourceTab(section) {
    resourceError = '';
    resourceSection = section;
    clearResourceHash();
    render();
    byId(`resource-tab-${section}`).focus({ preventScroll: true });
  }
  byId('chapter-content').addEventListener('keydown', event => {
    const tab = event.target.closest('[role="tab"]');
    if (!tab || !['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    const sections = Object.keys(resourceSections).filter(key => resources[key].length);
    const index = sections.indexOf(tab.dataset.resourceSection);
    const next = event.key === 'Home' ? 0 : event.key === 'End' ? sections.length - 1 : (index + (event.key === 'ArrowRight' ? 1 : -1) + sections.length) % sections.length;
    event.preventDefault();
    selectResourceTab(sections[next]);
  });
  byId('chapter-content').addEventListener('toggle', event => {
    if (!event.target.matches('details[data-practice]')) return;
    const key = event.target.dataset.practice;
    if (event.target.open) collapsedPractices.delete(key);
    else collapsedPractices.add(key);
  }, true);
  byId('chapter-content').addEventListener('change', event => {
    if (event.target.matches('[data-quiz-option]')) {
      if (!event.target.checked || state.answers[event.target.dataset.quizOption]?.optionId === event.target.value) return;
      quizErrors.delete(event.target.dataset.quizOption);
      const step = capabilities[state.chapterIndex].subExercises.find(item => item.id === event.target.dataset.quizOption);
      if (step.knowledgeCheck) quizErrors.delete(`group:${step.knowledgeCheck}`);
      commit(progress.updateStep(state, capabilities[state.chapterIndex].id, event.target.dataset.quizOption, false, event.target.value));
      byId(event.target.id).focus({ preventScroll: true });
      return;
    }
    if (!event.target.matches('[data-step]')) return;
    commit(progress.updateStep(state, capabilities[state.chapterIndex].id, event.target.dataset.step, event.target.checked));
  });
  byId('chapter-content').addEventListener('submit', event => {
    if (event.target.matches('[data-quiz-group]')) {
      event.preventDefault();
      const groupId = event.target.dataset.quizGroup;
      const chapter = capabilities[state.chapterIndex];
      const questions = chapter.subExercises.filter(step => step.knowledgeCheck === groupId);
      const formData = new FormData(event.target);
      const answers = Object.fromEntries(questions.map(step => [step.id, formData.get(step.id)]));
      const missing = questions.find(step => !answers[step.id]);
      if (missing) {
        quizErrors.add(`group:${groupId}`);
        render();
        byId(`quiz-${missing.id}-0`).focus({ preventScroll: true });
        return;
      }
      quizErrors.delete(`group:${groupId}`);
      commit(progress.checkQuizGroup(state, chapter.id, groupId, answers));
      byId(`check-group-${groupId}`).focus({ preventScroll: true });
      return;
    }
    if (!event.target.matches('[data-quiz]')) return;
    event.preventDefault();
    const form = event.target;
    const answer = new FormData(form).get(form.dataset.quiz);
    if (!answer) {
      quizErrors.add(form.dataset.quiz);
      render();
      return;
    }
    quizErrors.delete(form.dataset.quiz);
    commit(progress.updateStep(state, capabilities[state.chapterIndex].id, form.dataset.quiz, true, answer));
    byId(`check-answer-${form.dataset.quiz}`).focus({ preventScroll: true });
  });
  byId('chapter-content').addEventListener('input', event => {
    if (event.target.id !== 'chapter-notes') return;
    const next = progress.createState(state);
    next.notes[capabilities[state.chapterIndex].id] = event.target.value;
    commit(next, false);
  });
  byId('chapter-content').addEventListener('click', async event => {
    if (event.target.closest('#back-to-topic')) {
      event.preventDefault();
      resourceSection = null;
      clearResourceHash();
      render();
      focusChapter();
      return;
    }
    const link = event.target.closest('a[data-resource]');
    if (link) {
      event.preventDefault();
      openResource(link.dataset.resource);
      if (window.location) window.location.hash = `resource-${link.dataset.resource}`;
      return;
    }
    const button = event.target.closest('button');
    if (!button || button.disabled) return;
    if (button.id === 'complete-chapter') commit(progress.completeChapter(state));
    if (button.id === 'finish-training') openCompletion();
    if (button.id === 'previous-chapter' && progress.canOpenChapter(state, state.chapterIndex - 1)) { commit({ ...state, chapterIndex: state.chapterIndex - 1 }); focusChapter(); }
    if (button.id === 'next-chapter') { commit(progress.advance(state)); focusChapter(); }
    if (button.dataset.resourceSection) selectResourceTab(button.dataset.resourceSection);
    if (button.dataset.printSheet) {
      finishPrint();
      const sheet = byId(`resource-${button.dataset.printSheet}`);
      printingSheet = sheet;
      sheet.setAttribute('data-printing', 'true');
      try { window.print(); } catch (error) { finishPrint(); throw error; }
    }
    if (Object.hasOwn(button.dataset, 'copyPrompt') || button.dataset.copyAsset) {
      const container = button.parentElement;
      const status = container.querySelector('.copy-status');
      const text = Object.hasOwn(button.dataset, 'copyPrompt') ? container.querySelector('pre').textContent : assets[button.dataset.copyAsset].text;
      try {
        await navigator.clipboard.writeText(text);
        status.textContent = 'Copied!';
      } catch {
        const range = document.createRange();
        range.selectNodeContents(container.querySelector('pre'));
        const selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(range);
        status.textContent = 'Clipboard unavailable. Text selected.';
      }
    }
  });
  byId('reset-button').addEventListener('click', () => byId('reset-dialog').showModal());
  byId('cancel-reset').addEventListener('click', () => byId('reset-dialog').close());
  byId('confirm-reset').addEventListener('click', () => {
    byId('reset-dialog').close();
    quizErrors.clear();
    resourceSection = null;
    clearResourceHash();
    commit(progress.reset());
    focusChapter();
  });
  window.addEventListener('storage', event => {
    if (event.key !== progress.storageKey && event.key !== null) return;
    const loaded = progress.load(storage);
    state = loaded.state;
    savedNotes = { ...state.notes };
    storageError = loaded.error;
    render();
  });
  window.addEventListener('hashchange', () => {
    if (window.location.hash.startsWith('#resource-')) openResource(window.location.hash.slice('#resource-'.length));
  });
  window.addEventListener('afterprint', finishPrint);
  render();
  if (window.location?.hash.startsWith('#resource-')) openResource(window.location.hash.slice('#resource-'.length));
})();
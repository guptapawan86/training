(() => {
  'use strict';
  const form = document.getElementById('catalog-filters');
  const search = document.getElementById('training-search');
  const solution = document.getElementById('solution-filter');
  const preparedBy = document.getElementById('preparer-filter');
  const stakeholder = document.getElementById('stakeholder-filter');
  const dateFilter = document.getElementById('date-filter');
  const toggle = document.getElementById('filter-toggle');
  const advanced = document.getElementById('advanced-filters');
  const pagination = document.getElementById('catalog-pagination');
  const previous = document.getElementById('page-previous');
  const next = document.getElementById('page-next');
  const pageSizeSelect = document.getElementById('page-size');
  const dateSort = document.getElementById('date-sort');
  const list = document.getElementById('training-list');
  let page = 1;
  const normalize = value => value.normalize('NFKC').toLowerCase().replace(/\s+/g, ' ').trim();
  const rows = [...document.querySelectorAll('[data-training]')].map(element => {
    const walker = document.createTreeWalker(element.querySelector('template').content, NodeFilter.SHOW_TEXT);
    const text = [];
    while (walker.nextNode()) text.push(walker.currentNode.textContent);
    const content = globalThis.createTrainingContent(JSON.parse(element.dataset.progress));
    return {
      element,
      content,
      progress: globalThis.createTrainingProgress(content),
      search: normalize(`${element.querySelector('a').textContent} ${text.join(' ')}`),
      solution: element.dataset.solution,
      date: element.dataset.date,
      preparedBy: JSON.parse(element.dataset.preparers),
      stakeholders: JSON.parse(element.dataset.stakeholders),
    };
  });

  function populate(select, values) {
    for (const value of [...new Set(values)].sort((a, b) => a.localeCompare(b))) {
      select.add(new Option(value, value));
    }
  }

  window.addEventListener('pageshow', refreshProgress);
  window.addEventListener('storage', event => {
    if (event.key === null || rows.some(row => row.progress.storageKey === event.key)) refreshProgress();
  });
  refreshProgress();
  if (!form) {
    rows.forEach(row => { row.element.hidden = false; });
    document.getElementById('no-results').hidden = rows.length > 0;
    return;
  }
  document.getElementById('catalog-options').hidden = false;
  populate(solution, rows.map(row => row.solution));
  populate(preparedBy, rows.flatMap(row => row.preparedBy));
  populate(stakeholder, rows.flatMap(row => row.stakeholders));

  function refreshProgress() {
    let storage;
    try { storage = window.localStorage; } catch { storage = null; }
    for (const row of rows) {
      const label = row.element.querySelector('.lab-progress');
      const percent = label.querySelector('.progress-percent');
      const statusLabel = label.querySelector('.progress-status');
      const { state, error } = row.progress.load(storage);
      if (error) {
        percent.textContent = 'Unavailable';
        statusLabel.textContent = '';
        label.dataset.status = 'unavailable';
        label.title = `Progress unavailable. ${error}`;
      } else {
        const summary = row.content.summarize(state.capabilities);
        const completed = summary.capabilityProgress.reduce((sum, chapter) => sum + chapter.completed, 0);
        const total = summary.capabilityProgress.reduce((sum, chapter) => sum + chapter.total, 0);
        const status = completed === total ? 'Complete' : completed ? 'In progress' : 'Pending';
        percent.textContent = `${summary.overallPercent}%`;
        statusLabel.textContent = status;
        label.dataset.status = status.toLowerCase().replaceAll(' ', '-');
        label.title = `${status}: ${completed} of ${total} exercises completed (${summary.overallPercent}%)`;
      }
      label.querySelector('use').setAttribute('href', `#progress-${label.dataset.status}`);
      label.setAttribute('aria-label', label.title);
      row.element.querySelector('.progress-detail').textContent = label.title;
      label.hidden = false;
    }
  }

  function dateRange() {
    const now = new Date();
    const isoDate = date => `${String(date.getFullYear()).padStart(4, '0')}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    const monthsAgo = months => {
      const date = new Date(now.getFullYear(), now.getMonth() - months, 1);
      const lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
      date.setDate(Math.min(now.getDate(), lastDay));
      return isoDate(date);
    };
    if (dateFilter.value === '12-24') return { from: monthsAgo(24), before: monthsAgo(12) };
    if (dateFilter.value === '24+') return { before: monthsAgo(24) };
    if (dateFilter.value) return { from: monthsAgo(Number(dateFilter.value)), through: isoDate(now) };
    return {};
  }

  function filter() {
    const range = dateRange();
    const terms = normalize(search.value).split(' ').filter(Boolean);
    const matches = rows.filter(row => terms.every(term => row.search.includes(term))
        && (!solution.value || row.solution === solution.value)
        && (!preparedBy.value || row.preparedBy.includes(preparedBy.value))
        && (!stakeholder.value || row.stakeholders.includes(stakeholder.value))
        && (!range.from || row.date >= range.from)
        && (!range.before || row.date < range.before)
        && (!range.through || row.date <= range.through));
    const count = matches.length;
    if (dateSort.value) {
      const direction = dateSort.value === 'oldest' ? 1 : -1;
      matches.sort((a, b) => direction * a.date.localeCompare(b.date));
    }
    const pageSize = pageSizeSelect.value === 'all' ? Math.max(1, count) : Number(pageSizeSelect.value);
    const pages = Math.ceil(count / pageSize);
    page = Math.min(page, Math.max(1, pages));
    const start = (page - 1) * pageSize;
    rows.forEach(row => { row.element.hidden = true; });
    matches.forEach(row => { list.append(row.element); });
    matches.slice(start, start + pageSize).forEach(row => { row.element.hidden = false; });
    document.getElementById('result-count').textContent = count
      ? `Showing ${start + 1}-${Math.min(start + pageSize, count)} of ${count} training labs`
      : '0 training labs found';
    document.getElementById('no-results').hidden = count > 0;
    pagination.hidden = false;
    previous.disabled = page === 1;
    next.disabled = page >= pages;
    document.getElementById('page-status').textContent = `Page ${count ? page : 0} of ${pages}`;
  }

  function resetPage() {
    page = 1;
    filter();
  }

  toggle.addEventListener('click', () => {
    advanced.hidden = !advanced.hidden;
    toggle.setAttribute('aria-expanded', String(!advanced.hidden));
  });
  form.addEventListener('submit', event => event.preventDefault());
  form.addEventListener('input', resetPage);
  form.addEventListener('change', resetPage);
  advanced.addEventListener('input', resetPage);
  advanced.addEventListener('change', resetPage);
  pageSizeSelect.addEventListener('change', resetPage);
  dateSort.addEventListener('change', resetPage);
  form.addEventListener('reset', event => {
    event.preventDefault();
    search.value = solution.value = preparedBy.value = stakeholder.value = dateFilter.value = '';
    resetPage();
    search.focus();
  });
  document.getElementById('clear-filters').addEventListener('click', event => {
    event.preventDefault();
    form.reset();
  });
  previous.addEventListener('click', () => {
    if (previous.disabled) return;
    page -= 1;
    filter();
  });
  next.addEventListener('click', () => {
    if (next.disabled) return;
    page += 1;
    filter();
  });
  form.hidden = false;
  filter();
})();
